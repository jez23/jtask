import React, { useContext } from 'react';
import setSideBarStateContext from '../contexts/setSideBarStateContext';

function TopNav(props){

    const setSideBarStateContext1 = useContext(setSideBarStateContext);
  
    return (
        <i className="fa fa-bars menuMobile" aria-hidden="true" onClick={() => setSideBarStateContext1(true)}></i>
    )
}

export default TopNav;