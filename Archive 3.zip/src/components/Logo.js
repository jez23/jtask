import React from 'react';
import logo from '../img/JTaskLogo.png';

function Logo(){
    return (
        <img src={logo} alt="JTask Logo" /> 
    )
}

export default Logo;