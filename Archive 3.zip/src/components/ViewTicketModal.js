import React, { useRef, useContext } from 'react';
import selectedTicketContext from '../contexts/selectedTicketContext';
import handleTicketEditContext from '../contexts/handleTicketEditContext';
import viewTicketFunctionContext from '../contexts/viewTicketFunctionContext';
import removeSelectedTicketContext from '../contexts/removeSelectedTicket';


function ViewTicketModal(props){

    const selectedTicketContext1 = useContext(selectedTicketContext);
    const handleTicketEditContext1 = useContext(handleTicketEditContext);
    const viewTicketFunctionContext1 = useContext(viewTicketFunctionContext);
    const removeSelectedTicketContext1 = useContext(removeSelectedTicketContext);
   
    function handleChange(changes){
        
        selectedTicketContext1.comments.push(changes)
        let select = selectedTicketContext1;
        textareaRef.current.value = ""
        handleTicketEditContext1(select.id, select)
    }
    let textareaRef = useRef();
   
    return (
      <div className="viewTicketModalContainer" onClick={(e) => viewTicketFunctionContext1(false)}>
        <div className="viewTicketModalInnerContainer"  onClick={(e) => e.stopPropagation()}>
            <div className="viewTicketModalContent">
                <div className='viewTicketCloseButton' onClick={removeSelectedTicketContext1}>
                    <i className="fa fa-window-close" aria-hidden="true" onClick={() => viewTicketFunctionContext1(false)}></i>
                </div>
                    <h2>{selectedTicketContext1.title}</h2>
                    <p className="viewTicketID"><i className="fa fa-id-badge" aria-hidden="true"></i> {selectedTicketContext1.id}</p>
                    <hr />
                    <h3><i className="fa fa-info-circle" aria-hidden="true"></i> Details:</h3>
                    <div className="viewTicketDetails">
                        <p><strong>TYPE:</strong> {selectedTicketContext1.type}</p>
                        <p><strong>PRIORITY:</strong> {selectedTicketContext1.priority}</p>
                        <p><strong>STATUS:</strong> {selectedTicketContext1.status}</p>
                        <p><strong>ASSIGNEE:</strong> {selectedTicketContext1.assignedTo}</p>
                        <p><strong>STORY POINTS:</strong> {selectedTicketContext1.points}</p>
                    </div>
                    <hr />
                    <h3><i className="fa fa-commenting-o" aria-hidden="true"></i> Description:</h3>
                    <p className="summaryText">{selectedTicketContext1.summary}</p>
                    <hr />
                    <h3><i className="fa fa-comments" aria-hidden="true"></i> Comments:</h3>
                    <div className="commentArea">
                        {selectedTicketContext1.comments.map(element => {
                               return (
                                        <div className="commentContainer" key={selectedTicketContext1.id + Math.random()}>
                                            <div className="commentImage">
                                                    <i className="fa fa-user-circle" aria-hidden="true"></i>
                                            </div>    
                                            <div className="commentMeta">
                                                    <p><strong>{element.userName}</strong></p>
                                                    <p>{element.comment}</p>
                                            </div>                                        
                                        <p></p>
                                        </div>
                                        )
                        })}
                        <textarea ref={textareaRef} className="" placeholder="Add a note about this ticket" cols="30" rows="5"></textarea>
                        <button onClick={e => handleChange({ userName: "Admin", comment: textareaRef.current.value})}>Add</button>
                    </div>
            </div>
        </div>
      </div> 
    )
}

export default ViewTicketModal;