import React, { useContext } from 'react';
import usersWithStateContext from '../contexts/usersWithStateContext';
import handleAddUserContext from '../contexts/handleAddUserContext';

/* function userModalContainerRemove(){
    const userModalContainer = document.querySelector('.userModalContainer');
    userModalContainer.classList.add('display')
} */

function newUserInputvalue(){

    const inputVal = document.querySelector('.addUser').value;
    document.querySelector('.addUser').value = ""
    return inputVal;
}

function UserModal(props){


    const usersWithStateContext1 = useContext(usersWithStateContext);
    const handleAddUserContext1 = useContext(handleAddUserContext);


    return (
        <div className="userModalContainer" onClick={() => props.setSideNavUserState(false)}>
            <div className="userModalInnerContainer" onClick={(e) => e.stopPropagation()}>
                <div className="userModalContent">
                    <div className='closeButton'>
                        <i className="fa fa-window-close" aria-hidden="true" onClick={() => props.setSideNavUserState(false)}></i>
                    </div>
                    <div className='titleUser'>
                        <h2><i class="fa fa-user-plus" aria-hidden="true"></i> ADD NEW USERS</h2>
                    </div>
                    <div className="user">
                            {usersWithStateContext1.map(el => (
                                <div className="addedUser" key={el}>
                                    <div className="addUserImage">
                                        <i class="fa fa-user-circle" aria-hidden="true"></i>
                                    </div>
                                    <div className="addUserMeta">
                                        <p>{el}</p>
                                    </div>
                                </div>))}
                    </div>
                    <div className="add">
                            <input placeholder="Add new users here." className="addUser"></input>
                            <button onClick={() => handleAddUserContext1(newUserInputvalue())}>Add</button>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default UserModal;