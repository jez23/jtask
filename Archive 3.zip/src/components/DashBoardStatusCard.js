import React, {useCallback, useContext} from 'react';
import StatusCardTicket from './StatusCardTicket';
import ticketWithContext from '../contexts/ticketWithContext';
import handleTicketEditContext from '../contexts/handleTicketEditContext';
import newTicketFunctionContext from '../contexts/newTicketFunctionContext';


function DashBoardStatusCard(props){


  const ticketsContext = useContext(ticketWithContext);
  const handleTicketEditContext1 = useContext(handleTicketEditContext);
  const newTicketFunctionContext1 = useContext(newTicketFunctionContext);


     /*https://www.youtube.com/watch?v=jfYWwQrtzzY */
     const dragOver = useCallback( () => {
       // console.log(props.title, props.draggable_id)
          handleChange(props.title, props.draggable_id) 
        },
        [props.title, props.draggable_id],
      );
  
  
    function handleChange(changes, id){
         
        let ticket = ticketsContext.find(ticket => ticket.id === id)
    
        ticket.status = changes;
        handleTicketEditContext1(id,  ticket)
      } 


      function newTicket(){
        //console.log(1, "wruff")
        newTicketFunctionContext1(true)
      }
  
      return (
          <div className="statusCardContainer">
           
              <h3>{props.title}</h3>
              <div className="dashBoardStatusCard" onDragEnter={dragOver}>
             
              
                  {
                    ticketsContext.filter(ticket=>ticket.status===props.title).map(ticket => 
                      <StatusCardTicket 
                        {...ticket} 
                        key={ticket.id} 
                        onDrag = {props.onDrag}
                      />
                    )
                  }
  
              
              </div>
              <button onClick={() => newTicket()} /* className="modalButton" */>Add new ticket</button>
          </div>
      )
  }
  
  export default DashBoardStatusCard;