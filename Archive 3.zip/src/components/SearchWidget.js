import React from 'react';
import Search from './Search';
import SprintDropDown from './SprintDropDown';


function SearchWidget(){
    return (
        <div className="searchWidget">
                <Search />
                <SprintDropDown />
        </div>
    )
}


export default SearchWidget;