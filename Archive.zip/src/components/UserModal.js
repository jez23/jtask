import React from 'react';


function userModalContainerRemove(){
    const userModalContainer = document.querySelector('.userModalContainer');
    userModalContainer.classList.add('display')
}

function newUserInputvalue(){
    const inputVal = document.querySelector('.addUser').value;
    document.querySelector('.addUser').value = " "
    return inputVal;
}

function UserModal(props){
    return (
        <div className="userModalContainer display">
            <div className="userModalInnerContainer">
                <div className="userModalContent">
                    <div className='closeButton'>
                        <i className="fa fa-window-close" aria-hidden="true" onClick={userModalContainerRemove}></i>
                    </div>
                    <div className='titleUser'>
                        <h2 >Add or delete a users</h2>
                    </div>
                    <div className="user">
                        <ol>
                            {props.usersWithState.map(el => (
                                <li key={el}>{el}</li>))}
                        </ol>
                    </div>
                    <div className="add">
                            <input placeholder="Add User" className="addUser"></input>
                            <button onClick={() => props.handleAddUser(newUserInputvalue())}>Add</button>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default UserModal;