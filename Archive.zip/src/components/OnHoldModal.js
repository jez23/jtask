import React from 'react';

function OnHoldModal(props){


    function closer(){
        const closer = document.querySelector('.onHoldModalContainer');
        closer.classList.add('display');
    }
    return (

        <div className="onHoldModalContainer display">
            <div className="onHoldModalInnerContainer">
                <div className="onHoldModalContent">
                    <div className='onHoldcloseButton'>
                        <i className="fa fa-window-close" aria-hidden="true" onClick={closer}></i>
                    </div>
                    {props.ticketsWithState.map( el => (
                        <p>{el.title}</p>
                    ))}
                </div>
            </div>
       </div> 
    )
}

export default OnHoldModal;