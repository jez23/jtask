import React from 'react';

function ViewTicketModal(props){

    function closer(){
        const closer = document.querySelector('.viewTicketModalContainer');
        closer.classList.add('display');
    }

    return (
      <div className="viewTicketModalContainer display">
        <div className="viewTicketModalInnerContainer">
            <div className="viewTicketModalContent">
                <div className='viewTicketCloseButton' onClick={props.removeSelectedTicket}>
                    <i className="fa fa-window-close" aria-hidden="true" onClick={closer}></i>
                </div>
                    <h2>{props.selectedTicket.title}</h2>
                    <p className="viewTicketID"><i class="fa fa-id-badge" aria-hidden="true"></i> {props.selectedTicket.id}</p>
                    <hr />
                    <h3><i className="fa fa-info-circle" aria-hidden="true"></i> Details:</h3>
                    <div className="viewTicketDetails">
                        <p><strong>TYPE:</strong> {props.selectedTicket.type}</p>
                        <p><strong>Priority:</strong> {props.selectedTicket.priority}</p>
                        <p><strong>STATUS:</strong> {props.selectedTicket.status}</p>
                        <p><strong>ASSIGNEE:</strong> {props.selectedTicket.assignedTo}</p>
                    </div>
                    <hr />
                    <h3><i className="fa fa-commenting-o" aria-hidden="true"></i> Description:</h3>
                    <p>{props.selectedTicket.summary}</p>
                    <hr />
                    <h3><i class="fa fa-comments" aria-hidden="true"></i> Comments:</h3>
                    <div className="commentArea">
                        <textarea placeholder="Add a note about this ticket" cols="30" rows="5"></textarea>
                        <button>Add</button>
                    </div>
            </div>
        </div>
      </div> 
    )
}

export default ViewTicketModal;