import React from 'react';

function BacklogModal(props){


    function closer(){
        const closer = document.querySelector('.backlogModalContainer');
        closer.classList.add('display');
    }


    return (
    <div className="backlogModalContainer display">
        <div className="backlogInnerContainer">
            <div className="backlogModalContent">
                <div className='backlogCloseButton'>
                    <i className="fa fa-window-close" aria-hidden="true" onClick={closer}></i>
                </div>
                {props.ticketsWithState.map( el => (
                        <p>{el.title}</p>
                    ))}
            </div>
        </div>
    </div> 
    )
}

export default BacklogModal;