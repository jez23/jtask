import React from 'react';

function SideNavButton(props) {
    return ( 
    <button className="sideNav__button" onClick={props.click}>{props.title}</button>
    )
}

export default SideNavButton;