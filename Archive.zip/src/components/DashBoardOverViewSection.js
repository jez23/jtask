import React from 'react';
import DashBoardStatusCard from './DashBoardStatusCard';
import Modal from './Modal';
import EditModal from './EditModal';
import UserModal from './UserModal';
import OnHoldModal from './OnHoldModal';
import BacklogModal from './BacklogModal';
import ViewTicketModal from './ViewTicketModal';

function DashBoardOverView(props){

    return (
        <>
        <div className="dashBoardOverView">

            <DashBoardStatusCard title="New" color="blue" handleTicketEdit={props.handleTicketEdit} ticketsWithState={props.ticketsWithState}  handleTicketSelect={props.handleTicketSelect}/>
            <DashBoardStatusCard title="Open" color="red"  handleTicketEdit={props.handleTicketEdit} ticketsWithState={props.ticketsWithState}  handleTicketSelect={props.handleTicketSelect}/>
            <DashBoardStatusCard title="In Progress" color="green" handleTicketEdit={props.handleTicketEdit} ticketsWithState={props.ticketsWithState}  handleTicketSelect={props.handleTicketSelect}/>
            <DashBoardStatusCard title="Resolved" color="yellow" handleTicketEdit={props.handleTicketEdit} ticketsWithState={props.ticketsWithState}  handleTicketSelect={props.handleTicketSelect}/>
            <DashBoardStatusCard title="Verified" color="pink" handleTicketEdit={props.handleTicketEdit} ticketsWithState={props.ticketsWithState}  handleTicketSelect={props.handleTicketSelect}/>
            <DashBoardStatusCard title="Closed" color="purple" handleTicketEdit={props.handleTicketEdit} ticketsWithState={props.ticketsWithState}  handleTicketSelect={props.handleTicketSelect}/>
        </div>
        <Modal  
            handleTicketAdd={props.handleTicketAdd}
            ticketsWithState={props.ticketsWithState}
            setEmptyTicketsFunction={props.setEmptyTicketsFunction}
            emptyTicketsWithState={props.emptyTicketsWithState}
            usersWithState={props.usersWithState}/>
        
        {props.selectedTicket &&  <EditModal
            handleTicketAdd={props.handleTicketAdd}
            ticketsWithState={props.ticketsWithState}
            handleTicketEdit={props.handleTicketEdit}
            selectedTicket={props.selectedTicket}
            removeSelectedTicket={props.removeSelectedTicket}
            usersWithState={props.usersWithState}/> }
        
         <UserModal
            setUserFunction={props.setUserFunction}
            usersWithState={props.usersWithState}
            handleAddUser={props.handleAddUser}/>
        
        <OnHoldModal 
            ticketsWithState={props.ticketsWithState}/>

         <BacklogModal 
             ticketsWithState={props.ticketsWithState}/>

        {props.selectedTicket && <ViewTicketModal 
            selectedTicket={props.selectedTicket}
            ticketsWithState={props.ticketsWithState}
            removeSelectedTicket={props.removeSelectedTicket}/>}    

        </>


           
    )
}


export default DashBoardOverView;