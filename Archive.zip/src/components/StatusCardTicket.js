import React, { useEffect } from "react";

function StatusCardTicket(props){

    useEffect(() => {
            const archiveButton = document.querySelector('.archiveButton');
            const changeStatus = document.querySelector('.reassignTicket');

            archiveButton.addEventListener('click', () => {
                changeStatus.classList.toggle('display');
            })

    })
    const date = new Date();
    const getYear = date.getFullYear();

    function dragStartHandlerStart(event) {
        event.target.classList.add('dragging');
    }
    function dragStartHandlerEnd(event) {
        event.target.classList.remove('dragging');
    }
    /* function viewTicketModalContainerRemove(){
       
        let ModalContainerView = document.querySelector(name);
        ModalContainerView.classList.remove('display');
    } 
     function viewEditModalContainerRemove(){
        const editModalContainer = document.querySelector('.editModalContainer');
        editModalContainer.classList.remove('display');
    } 
 */
  
    return (
        <div className="statusCardTicket" draggable="true" id={props.id}  onDragStart={dragStartHandlerStart} onDragEnd={dragStartHandlerEnd}>
            <div className="statusCardTicket__info">
                <div className="statusCardTicket__priority">
                <p className="statusUpdate">{props.status}</p>
                </div>
                <h3>{props.title}</h3>
                <p>Date: {getYear}</p>
                <p>{props.id}</p>
            </div>
            <div className="statusCardTicket__nav">
                    <div className="viewTicket" onClick={() => props.handleTicketSelect(props.id, '.viewTicketModalContainer')}>
                        <i className="fa fa-eye" aria-hidden="true" ></i>
                    </div>
                    <div className="editTicket">
                        <i className="fa fa-pencil" aria-hidden="true" onClick={() => props.handleTicketSelect(props.id, '.editModalContainer')}></i>
                    </div>
                    <div className="archiveButton">
                        <i className="fa fa-archive" aria-hidden="true"></i>
                        <div className="reassignTicket display">
                            <ul>
                                <li>On Hold</li>
                                <li>Add To BackLog</li>
                            </ul>
                        </div>
                    </div>
                  
            </div>
        </div>
    )

}

export default StatusCardTicket;