import React from 'react';
import DashBoardOverViewSection from './DashBoardOverViewSection';
import SearchWidget from './SearchWidget';
import Header from './Header';


function Dashboard(props){
    return (
        <div className="dashBoard">
                <Header />
                <SearchWidget />
                <DashBoardOverViewSection 
                    ticketsWithState={props.ticketsWithState}
                    handleTicketAdd={props.handleTicketAdd}
                    handleTicketEdit={props.handleTicketEdit}
                    handleTicketSelect={props.handleTicketSelect}
                    selectedTicket={props.selectedTicket}
                    removeSelectedTicket={props.removeSelectedTicket}
                    setEmptyTicketsFunction={props.setEmptyTicketsFunction}
                    emptyTicketsWithState={props.emptyTicketsWithState}
                    usersWithState={props.usersWithState}
                    setUserFunction={props.setUserFunction}
                    handleAddUser={props.handleAddUser}/>
        </div>
    )
}

export default Dashboard;