import React, { useEffect } from 'react';

function TopNav(){
    useEffect( ( ) => {
            const menuMobile = document.querySelector(".menuMobile");
            const sideNav = document.querySelector(".sideNavContainer");

            menuMobile.addEventListener('click', () =>{
                sideNav.classList.toggle('display')
            })
    })
    return (
        <i className="fa fa-bars menuMobile" aria-hidden="true"></i>
    )
}

export default TopNav;