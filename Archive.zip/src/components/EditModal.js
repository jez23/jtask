import React from 'react';

function EditModal(props){
   
    function handleChange(changes){
          props.handleTicketEdit(props.selectedTicket.id,  {...props.selectedTicket, ...changes})
    }
    return (
        <div className="editModalContainer display">
            <div className="editModal">
                <button>X</button>
                <h3>Edit a task:</h3>
                <input placeholder="Title" value={props.selectedTicket.title} onChange={e => handleChange({title: e.target.value})}/>
                <input placeholder="Summary" value={props.selectedTicket.summary} onChange={e => handleChange({summary: e.target.value})}/>
                <input placeholder="Type" value={props.selectedTicket.type} onChange={e => handleChange({type: e.target.value})}/>
                <input placeholder="Priority" value={props.selectedTicket.priority} onChange={e => handleChange({priority: e.target.value})}/>
                <input placeholder="Points" value={props.selectedTicket.points} onChange={e => handleChange({ points: e.target.value})}/>
                <input placeholder="Sprint" value={props.selectedTicket.sprint} onChange={e => handleChange({sprint: e.target.value})}/>
                <select name="users">
                       { props.usersWithState.map(el => (
                           <option value={el} key={el}>{el}</option>
                       ))}
                </select>
                <select name="status" onChange={e => handleChange({status: e.target.value})}>
                    <option value="New">Change Status</option>
                    <option value="New">New</option>
                    <option value="Open">Open</option>
                    <option value="In Progress">In Progress</option>
                    <option value="Resolved">Resolved</option>
                    <option value="Verified">Verified</option>
                    <option value="Closed">Closed</option>
                </select>
                <button className="modalSave" onClick={props.removeSelectedTicket}>Save</button>
            </div>
        </div>
    );
}

export default EditModal;