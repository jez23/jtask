import React, { useEffect } from 'react';
import SideNavButton from './SideNavButton';

function SideNav() {

    useEffect(() => {
        const closingSideNav = document.querySelector('.closingSideNav');
        const sideNavContainer = document.querySelector('.sideNavContainer');
        closingSideNav.addEventListener('click', () => {
            sideNavContainer.classList.add('display');
        })
        sideNavContainer.addEventListener('click', (event) => {
            sideNavContainer.classList.add('display');
        })
    })

    function userModalContainerRemove(){
        const userModalContainer = document.querySelector('.userModalContainer');
        userModalContainer.classList.remove('display');
    }
    function onHoldModalContainerRemove(){
        const onHoldModalContainer = document.querySelector('.onHoldModalContainer');
        onHoldModalContainer.classList.remove('display');
    }
    function backlogModalContainerRemove(){
        const backlogModalContainer = document.querySelector('.backlogModalContainer');
        backlogModalContainer.classList.remove('display');
    }
    
    
    return (
        <div className="sideNavContainer display">
            <div className="sideNavInnerContainer">
                <div className="sideNav">
                    <button className="closingSideNav">X</button>
                    <SideNavButton title="Dash Board" click={() => console.log("Click")}/>
                    <SideNavButton title="Users" click={() => userModalContainerRemove()}/>
                    <SideNavButton title="On Hold" click={() => onHoldModalContainerRemove()}/>
                    <SideNavButton title="Back Log" click={() => backlogModalContainerRemove()}/>              
                </div>
            </div>
        </div>
    );
  }
  
  export default SideNav;