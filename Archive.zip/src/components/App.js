import React, { useState } from 'react';
import '../css/main.css';
import SideNav from './SideNav';
import Dashboard from './Dashboard';
import { v4 as uuidv4 } from 'uuid';

function App() {
  const [emptyTicketsWithState, setEmptyTicketsFunction] = useState(emptyTicket);
  const [selectedTicketId, setSelectedTicketIdFunction] = useState();
  const [ticketsWithState, setTicketsFunction] = useState(tickets);
  const [usersWithState, setUserFunction] = useState(users);
  const selectedTicket = ticketsWithState.find(ticket => ticket.id === selectedTicketId)
  function handleTicketAdd(newObject){
    const newTicket = {
        id : uuidv4(),
        title: newObject.title,
        date: '',
        summary: newObject.summary,
        type: newObject.type,
        priority: newObject.priority,
        status: newObject.status,
        resolution: false,
        points: newObject.points,
        sprint: newObject.sprint,
        assignedTo: ''
    }
    setTicketsFunction([...ticketsWithState, newTicket]);
    setEmptyTicketsFunction(emptyTicket);
  }
  function handleTicketEdit(id, ticket){
console.log("YES")
    console.log(id, "lllllll")
    console.log(ticket, "ppppppp")
       const newTicket = [...ticketsWithState];
      const index = newTicket.findIndex(t => t.id === id);
      newTicket[index] = ticket;
      console.log(newTicket[index], "ssssssssss")
      console.log(newTicket)
   /* setTicketsFunction(newTicket)  */
  }
  async function handleTicketSelect(id, name){
    console.log("Hello")
       await setSelectedTicketIdFunction(id)
   
      let ModalContainerView = document.querySelector(name);
      ModalContainerView.classList.remove('display');
  }
  function removeSelectedTicket(){
      setSelectedTicketIdFunction(null);
  }
  function handleAddUser(newUser){
    setUserFunction([...usersWithState, newUser])
  }
  return (
      <div className="mainContainer">
        <SideNav />
        <Dashboard
          ticketsWithState={ticketsWithState}
          handleTicketAdd={handleTicketAdd}
          handleTicketEdit={handleTicketEdit}
          handleTicketSelect={handleTicketSelect}
          selectedTicket={selectedTicket}
          removeSelectedTicket={removeSelectedTicket}
          setEmptyTicketsFunction={setEmptyTicketsFunction}
          emptyTicketsWithState={emptyTicketsWithState}
          usersWithState={usersWithState}
          setUserFunction={setUserFunction}
          handleAddUser={handleAddUser}/>
      </div>
  );
}

const tickets = [
  {
    id : uuidv4(),
    title: "1Fixing a bug because it broke",
    date: '',
    summary: '',
    type: "Bug",
    priority: "Blocker",
    status: "Closed",
    resolution: false,
    points: 4,
    sprint: 4,
    assignedTo: ''
  },
  {
    id : uuidv4(),
    title: "2Fixing a bug because it broke",
    date: '',
    summary: '',
    type: "Bug",
    priority: "High",
    status: "In Progress",
    resolution: false,
    points: 4,
    sprint: 4, 
    assignedTo: ''
  },
  {
    id : uuidv4(),
    title: "3Fixing a bug because it broke",
    date: '',
    summary: '',
    type: "Bug",
    priority: "Low",
    status: "In Progress",
    resolution: false,
    points: 4,
    sprint: 4,
    assignedTo: ''
  },
  {
    id : uuidv4(),
    title: "3Fixing a bug because it broke",
    date: '',
    summary: '',
    type: "Bug",
    priority: "Low",
    status: "On Hold",
    resolution: false,
    points: 4,
    sprint: 4,
    assignedTo: ''
  }
]


const emptyTicket = {
  id : uuidv4(),
  title: '',
  summary: '',
  type: '',
  priority: '',
  points: 0,
  sprint: 0,
  status: ''
}

const users = ["Jez", "Mark", "John", "Sam"];

export default App;
