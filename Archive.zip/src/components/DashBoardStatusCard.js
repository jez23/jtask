import React from 'react';
import StatusCardTicket from './StatusCardTicket';

function DashBoardStatusCard(props){

    /*https://www.youtube.com/watch?v=jfYWwQrtzzY */
    function dragOver(e){

       console.log(e.target.id)

        if(e.target.classList.contains('dashBoardStatusCard')){
           // console.log( e.target);
           // console.log(props.title , "tttttttt");
                const draggable = document.querySelector('.dragging');

            // console.log(draggable.id, "pppppppppp")   
                e.target.appendChild(draggable);
                draggable.style.backgroundColor = props.color;
           handleChange(props.title, draggable.id) 
        } 
    }
    

    function handleChange(changes, id){
         
        let ticket = props.ticketsWithState.filter(ticket => ticket.id === id)
  
      ticket.status = changes;
      console.log(ticket.status , "mmmmmmmmmmmmmm")
      props.handleTicketEdit(id,  ticket)
    } 

    return (
        <div className="statusCardContainer"  >
                <h3>{props.title}</h3>
            <div className="dashBoardStatusCard" onDragOver={(e) => dragOver(e)}>
            
            
                {props.ticketsWithState.filter(ticket => { 
                    return props.title === ticket.status
                }).map(ticket => {
                    return <StatusCardTicket {...ticket} key={ticket.id}  handleTicketSelect={props.handleTicketSelect}/>
                })
                }

            
            </div>
            <button className="modalButton">Add new ticket</button>
        </div>
    )
}

export default DashBoardStatusCard;