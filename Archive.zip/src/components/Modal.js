import React, { useEffect } from 'react';

function Modal(props){

    useEffect(() => {
        const modal = document.querySelector('.modalContainer');
        const modalButton = document.querySelectorAll('.modalButton');
        const modalSave = document.querySelector('.modalSave');
      
        
        modalButton.forEach((el) => {
                el.addEventListener('click', () => {
                    modal.classList.remove('display');
                })
        })
        modalSave.addEventListener('click', () => {
            console.log("CLICK")
                    modal.classList.add('display');
        })      
       
    })

   
 
    return (
        <div className="modalContainer display">
            <div className="modal">
                <button>X</button>
                <h3>Create a new task:</h3>
                    <input placeholder="Title" value={props.emptyTicketsWithState.title} onChange={e => props.setEmptyTicketsFunction({...props.emptyTicketsWithState, title: e.target.value})} required/>
                    <input placeholder="summary" value={props.emptyTicketsWithState.summary} onChange={e => props.setEmptyTicketsFunction({...props.emptyTicketsWithState, summary: e.target.value})}/>
                    <input placeholder="type" value={props.emptyTicketsWithState.type} onChange={e => props.setEmptyTicketsFunction({...props.emptyTicketsWithState, type: e.target.value})}/>
                    <input placeholder="priority" value={props.emptyTicketsWithState.priority} onChange={e => props.setEmptyTicketsFunction({...props.emptyTicketsWithState, priority: e.target.value})}/>
                    <input placeholder="points" value={props.emptyTicketsWithState.points} onChange={e => props.setEmptyTicketsFunction({...props.emptyTicketsWithState, points: e.target.value})}/>
                    <input placeholder="sprint" value={props.emptyTicketsWithState.sprint} onChange={e => props.setEmptyTicketsFunction({...props.emptyTicketsWithState, sprint: e.target.value})}/>
                   {/*  <input placeholder="status" value={props.emptyTicketsWithState.status} onChange={e => props.setEmptyTicketsFunction({...props.emptyTicketsWithState, status: e.target.value})}/> */}
                   <select name="users">
                       { props.usersWithState.map(el => (
                           <option value={el} key={el}>{el}</option>
                       ))}
                    </select>


                    <select name="status" onChange={e => props.setEmptyTicketsFunction({...props.emptyTicketsWithState, status: e.target.value})} required>
                        <option value="New">Change Status</option>
                        <option value="New">New</option>
                        <option value="Open">Open</option>
                        <option value="In Progress">In Progress</option>
                        <option value="Resolved">Resolved</option>
                        <option value="Verified">Verified</option>
                        <option value="Closed">Closed</option>
                    </select>

                    <button className="modalSave" onClick={() => props.handleTicketAdd(props.emptyTicketsWithState)}>Save</button>
            </div>
        </div>
    )
}

export default Modal;